//
// Created by Dule on 6/14/2023.

//Од стандарден влез се чита цел број N (N<100) и потоа N низи од знаци. Низите знаци содржат букви, цифри и специјални знаци, а секоја од нив не е поголема од 50 знаци.
//
//Да се напише програма што ќе ги отпечати на екран сите низи од знаци во кои се содржи поднизата А1c  најмалку 2 пати (пр. A1c01АA1c92, 12A1cwwA1cxy, аA1cwA1cA1ccA1cxab) според редоследот како што се прочитани од влезот. При печатење на зборовите, сите алфабетски знаци треба да се испечатат со мали букви.
//
//Пример
//
//        Влез:
//
//6
//
//Ekjqh!!lkjsdh
//
//        A1c01АA1c92
//
//12A1cwwA1cxy
//
//12A1cwwA1bxy
//
//аA1cwA1cA1ccA1cxab
//
//        nemaA1c_povekjepati
//
//
//Излез
//
//        а1c01аа1c92
//
//12а1cwwа1cxy
//
//аа1cwа1cа1ccа1cxab
//
#include <stdio.h>
#include <ctype.h>
#include <string.h>
void ispecati(char *line){
    for (int i = 0; i < strlen(line); ++i) {

    }
}
void proveri(char *line){
    for (int i = 0; i < strlen(line); ++i) {
        line[i]= tolower(line[i]);
    }
    int counter=0;
    for (int i = 0; i < strlen(line); ++i) {

        if(line[i]=='a'){
            if(line[i+1]=='1'){
                if(line[i+2]=='c'){
                    counter++;
                }
            }
        }
    }
    if(counter>1) {
        for (int i = 0; i < strlen(line); ++i) {
            line[i]= tolower(line[i]);
        }
        puts(line);

    }

}
int main(){
    int n;
    scanf("%d",&n);

    char niza[n][50];
    for (int i = 0; i < n; ++i) {
        scanf("%s",&niza[i]);
        proveri(niza[i]);


    }
}