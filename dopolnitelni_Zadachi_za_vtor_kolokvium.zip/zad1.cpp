//
// Created by Dule on 6/15/2023.
//
/*
 * Од стандарден влез се чита цел број N (N<=100) и потоа N низи од знаци. Низите знаци содржат букви, цифри и специјални знаци (без знаци за празно место), а секоја од нив не е подолга од 80 знаци.

Да се напише програма со која што на стандарден излез ќе се отпечати најдолгата низа, којашто е палиндром (се чита исто од од лево на десно и од десно на лево) и што содржи барем еден специјален знак. Ако нема такви низи, се печати "Nema!". Ако има две или повеќе низи што го задоволуваат овој услов, се печати првата низа којашто го задоволува условот.

Влез:

9

a!bcdedcb!a

Kfd?vsvv98_89vvsv?dfK

Ccsvsdvdfv

342425vbbcb

352!2353696969625

gdg??dfg!!

5336346644747

8338736767867

12344321

Излез:

Kfd?vsvv98_89vvsv?dfK


 * */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
void removeNewLine(char* str) {
    int len= strlen(str);
    if(len>0&& str[len-1]=='\n'){
        str[len-1]='\0';

    }
}
int palindromint(char* str) {
    int len = strlen(str);
    for (int i = 0, j = len - 1; i < len/2; i++, j--) {
        if (str[i] != str[len-i-1]) {
            return 0; // Не е палиндром
        }
    }
    return 1; // Е палиндром
}
int specijalenZnak(char *line){
    for (int i = 0; i < strlen(line); ++i) {
        if(!isalnum(line[i])){
            return 1;
        }
    }
    return 0;
}
int main(){
    int n;
    int max=0;
    char maxLine[100];
    int flag=1;
    scanf("%d\n",&n);
    for (int i = 0; i < n; ++i) {
        char line[81];
        fgets(line,sizeof (line),stdin);
        removeNewLine(line);
        if(palindromint(line)&& specijalenZnak(line)){
            if(flag){
                max= strlen(line);

                strcpy(maxLine,line);
                flag=0;
            }
            else{
                if(strlen(line)>max){
                    max= strlen(line);
                    strcpy(maxLine,line);
                }
            }}


    }
    if(flag){
        printf("Nema!");
        return 0;
    }
    puts(maxLine);

}