//
// Created by Dule on 6/17/2023.
//
/*
 * Од стандарден влез се внесуваат непознат број на реченици претставени преку текстуални низи (стрингови) секоја не подолга од 100 знаци и секоја во нов ред. Програмата треба да го најде стрингот кој содржи најмногу сврзници и да го испечати заедно со бројот на најдените сврзници. За сврзници се сметаат сите зборови составени од една, две или три букви. Зборовите во текстуалната низа се одделени со едно или повеќе прзани места и/или интерпункциски знак.

Броењето на сврзници во дадена текстуална низа треба да се реализира во посебна функција. Решенијата без користење функција ќе бидат оценети со најмногу 40% од поените.

Ако има повеќе реченици со ист максимален број на сврзници, се печати прво најдената.

Објаснување на тест примерот:
Бројот на сврзници по реченици е 2, 3, 4, 2, 4 и 7 соодветно. Најмногу сврзници има по последната реченица па се печати бројот 7 и содржината на таа реченица.


For example:

Input	Result
Svrznicite vo makedonskiot jazik se sluzbeni zborovi
odnosno niv gi upotrebuvame za povrzuvanje oddelni zborovi
vo ramkite na edna recenica ili poveḱe recenici vo edna slozena recenica.
Pri povrzuvanjeto, svrznicite gi izrazuvaat odnosite megju zborovite
ili megju recenicite, pa taka sprotiven odnos se iskazhuva so
ama ili no, a usloven odnos so ako itn.
7: ama ili no, a usloven odnos so ako itn.

 * */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int prebrojuvanje(char *rechenica){
    int counter=0;
    int counter2=0;

    for (int i = 0; i < strlen(rechenica); ++i) {
        if(isalpha(rechenica[i])){
            counter++;
        }
        else{
            if(counter<=3&&counter>=1){
                counter2++;
            }
            counter=0;}
    }
    return counter2;
}

int main(){
    char rechenica[100];
    int flag=1;
    int max=0;
    char maxLine[100];
    while (fgets(rechenica,100,stdin)){
        int dolzina=(int) strlen(rechenica);
        rechenica[dolzina-1]='\0';
        int zborovi= prebrojuvanje(rechenica);
        if(max<zborovi){
            max=zborovi;
            strcpy(maxLine,rechenica);

        }
    }
    printf("%d: ",max);
    puts(maxLine);


}