//
// Created by Dule on 6/14/2023.
//
//од тастаута се внесуваат димензиите m и n на матрица од цели броеви,
//Amxn (0<m,n<30) и нејзините елементи. Потоа се внесувааат два
//цели броја r и k (индекси на редица/колона од матрица т.е 0<=r<m и 0<=k<n)
//Да се напише програма која  ја трансформира матрицата A така што
//елементите над редицата r и лево од колоната k се заменуваат со минимална
//вредност од матрица A.
//Наводобиената матрица да се запише во датотека "matrica.txt"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main(){
    FILE *f= fopen("C:\\Users\\Dule\\CLionProjects\\untitled1\\sp\\output.txt","w");
    int m,n, r,k;
    int matrix[100][100];
    scanf("%d %d",&m,&n);
    scanf("%d %d",&r,&k);
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            scanf("%d",&matrix[i][j]);
        }
    }
    int min=99999;
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            if(matrix[i][j]<min){
                min=matrix[i][j];
            }
        }
    }
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            if(i<r&&j<k){
                printf("%d ",min);
            }
            else printf("%d ",matrix[i][j]);


        }
        printf("\n");
    }
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            fprintf(f,"%d", matrix[i][j]);
        }
        fprintf(f,"\n");
    }
    fclose(f);
}
